A Pen created at CodePen.io. You can find this one at http://codepen.io/joe-watkins/pen/RPZbrW.

 Accessible grid style gallery with off-canvas image details prototype with focus management and keyboard support.