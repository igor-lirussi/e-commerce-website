A Pen created at CodePen.io. You can find this one at http://codepen.io/dudleystorey/pen/uEnKF.

 Transitioned gallery for four images. A detailed tutorial [on my blog](http://thenewcode.com/846/Quad-Image-Gallery)