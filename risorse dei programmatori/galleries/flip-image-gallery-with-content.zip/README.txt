A Pen created at CodePen.io. You can find this one at http://codepen.io/piupiupiu/pen/YyxWpd.

 A flip animation image with some hidden preview. When user hover on it, some sh*t happens.