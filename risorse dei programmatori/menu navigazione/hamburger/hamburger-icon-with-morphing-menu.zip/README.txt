A Pen created at CodePen.io. You can find this one at http://codepen.io/sergioandrade/pen/onkub.

 Creative menu made with html sass/css3 and JQuery.