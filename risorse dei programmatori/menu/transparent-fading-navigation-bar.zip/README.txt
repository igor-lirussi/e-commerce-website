A Pen created at CodePen.io. You can find this one at http://codepen.io/pirrera/pen/zapbh.

 Transparent Fading Navigation Bar with Mask Image