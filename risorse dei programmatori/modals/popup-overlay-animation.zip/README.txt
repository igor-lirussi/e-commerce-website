A Pen created at CodePen.io. You can find this one at https://codepen.io/elmanifico45/pen/RZgOWO.

 popup overlay using html and css and javascript 