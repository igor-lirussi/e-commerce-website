A Pen created at CodePen.io. You can find this one at http://codepen.io/simoberny/pen/XgEgGg.

 I see this method of paying on https://www.instant-gaming.com

Supported card:

4: VISA, 51 -> 55: MasterCard, 36-38-39: DinersClub, 34-37: American Express, 65: Discover, 5019: dankort