$(document).on('ready', function(){
	formCheck();
});

function formCheck()
{
	//UPDATE NAME
	$('input.name').each(function() {
   var elem = $(this);

   // Save current value of element
   elem.data('oldVal', elem.val());

   // Look for changes in the value
   elem.bind("propertychange change click keyup input paste", function(event){
      // If value has changed...
      if (elem.data('oldVal') != elem.val()) {
       // Updated stored value
       elem.data('oldVal', elem.val());

       // Do action
       $('.name-on-card, .sig-name').html($('input.name').val());
     }
   });
 });
	//UPDATE CARD NUMBER
	$('input.number').each(function() {
   var elem = $(this);

   // Save current value of element
   elem.data('oldVal', elem.val());

   // Look for changes in the value
   elem.bind("propertychange change click keyup input paste", function(event){
      // If value has changed...
      if (elem.data('oldVal') != elem.val()) {
       // Updated stored value
       elem.data('oldVal', elem.val());

       // Do action
			 $splitNumber = $('input.number').val().match(/.{1,4}/g);
       $('.card-front .card-number span').each(function(index){
				 $(this).html($splitNumber[index]);
			 });
				$('.card-back .card-number span').each(function(index){
				 $(this).html($splitNumber[index]);
			 });
     }
   });
 });
	//FLIP CARD WHEN CVV IS FOCUED
	$('input.cvv').on('focus', function(){
		$('.credit-card').removeClass('is-front').addClass('is-back');
	});
	$('input.cvv').on('focusout', function(){
		$('.credit-card').addClass('is-front').removeClass('is-back');
	});
	
	//UPDATE CVV
	$('input.cvv').each(function() {
   var elem = $(this);

   // Save current value of element
   elem.data('oldVal', elem.val());

   // Look for changes in the value
   elem.bind("propertychange change click keyup input paste", function(event){
      // If value has changed...
      if (elem.data('oldVal') != elem.val()) {
       // Updated stored value
       elem.data('oldVal', elem.val());

       // Do action
       $('div.cvv').html($('input.cvv').val());
     }
   });
 });
	
	//UPDATE DATE
	$('input#datepicker').each(function() {
   var elem = $(this);

   // Save current value of element
   elem.data('oldVal', elem.val());

   // Look for changes in the value
   elem.bind("propertychange change click keyup input paste", function(event){
      // If value has changed...
      if (elem.data('oldVal') != elem.val()) {
       // Updated stored value
       elem.data('oldVal', elem.val());

       // Do action
       $('.card-front .date').html($('input#datepicker').val());
     }
   });
 });
}